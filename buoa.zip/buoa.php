<?php
// Buoa! theme, https://github.com/datenstrom/yellow-themes/tree/master/buoa
// Copyright (c) 2013-2017 Datenstrom, https://datenstrom.se 
// This file may be used and distributed under the terms of the public license.

class YellowThemeBuoa
{
	const VERSION = "0.7.8";	
}

$yellow->themes->register("buoa", "YellowThemeBuoa", YellowThemeBuoa::VERSION);
?>
