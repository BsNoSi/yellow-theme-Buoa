﻿<div class="footer">
<div class="siteinfo">
<a href="<?php echo $yellow->page->base."/feed/" ?>">News-Feed</a> &bull; &copy;2010-<?php echo date("Y") ?> Norbert Simon &bull;
<a href="<?php echo $yellow->page->base."/contact/" ?>">Kontakt / Kommentar</a>  &bull;
<a href="<?php echo $yellow->text->get("yellowUrl") ?>">Betrieben mit Yellow</a>.
</div>
</div>
</div>
<?php echo $yellow->page->getExtra("footer") ?>
</body>
</html>